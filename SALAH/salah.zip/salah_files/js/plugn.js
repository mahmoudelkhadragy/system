$(function() {
    "use strict";

    ///////////////////////////////// height of the login /////////////////////////
    var windH = $(window).height();
    $(".login").height(windH);

    ////////////////////////////// change active navbar/////////////////


    //filtering inputs
    $(".user").blur(function() {
        var userChar = $(this).val().length;
        if( userChar <= 4 ) {
            $(".user-alert").slideDown(200);
        } else {
            $(".user-alert").slideUp(200);
        }
    });
    $(".passw").blur(function() {
        var passChar = $(this).val().length;
        if( passChar < 4 ) {
            $(".pass-alert").slideDown(200);
        } else {
            $(".pass-alert").slideUp(200);
        }
    });

    ////////////////////// search for  /////////////////////////////

    $("input#search").quicksearch('table tbody tr');

    ////////////////////// price value for  ////////////////////////

    function transferToDollars() {


        $("#eg-price").keyup(function () {
            var egyMoney    = $("#eg-price").val(),
                buyPrice    = $("#buy-price").val(),
                sellPrice   = $("#sell-price").val();

            if (buyPrice == "" && sellPrice == "" ){

            } else {
                var EgM = ( egyMoney / buyPrice );
                var DDM = ( egyMoney / sellPrice );
                var EEMONEY = ( ( EgM * sellPrice ) - egyMoney ).toFixed(2);
                $("#dollar-price").val((egyMoney / buyPrice ).toFixed(2));
                $("#saving").val( EEMONEY );
            }
        });

    }
    transferToDollars();

    ////////////////////// price value for  ////////////////////////
    function transferMoney() {

        $("#exist").keyup(function () {
            var transfer = $("#exist").val(),
                price    = $("#price").val();

                if(transfer == "" && price == ""){

                } else {
                    var transMony = (transfer / price);
                    $("#lebe").val(transMony.toFixed(2));
                }
        });
    }
    transferMoney();

    ////////////////////// suppliers inputs  ////////////////////////
    $(".supplier-form").submit(function () {
        var address_s   = $("#sup_address").val(),
            phone_s     = $("#sup_phone").val(),
            identity_s  = $("#sup_ident").val(),
            account_s   = $("#sup_account").val(),
            textNote_s  = $("#sup_anotherinfo").val();
        if(address_s == "") {
            $("#sup_address").val("لايوجد");
        }
        if(phone_s == "") {
            $("#sup_phone").val("لا يوجد");
        }
        if(identity_s == "") {
            $("#sup_ident").val("لا يوجد")
        }
        if(account_s == "") {
            $("#sup_account").val("لا يوجد")
        }
        if(textNote_s == "") {
            $("#sup_anotherinfo").val("لا يوجد")
        }
    });
    ////////////////////// clients inputs  ////////////////////////
    $(".clients-form").submit(function () {
        var address_c   = $("#address").val(),
            phone_c     = $("#phone").val(),
            identity_c  = $("#ident").val(),
            account_c   = $("#account").val(),
            textNote_c  = $("#anotherinfo").val();
        if(address_c == "") {
            $("#address").val("لايوجد");
        }
        if(phone_c == "") {
            $("#phone").val("لا يوجد");
        }
        if(identity_c == "") {
            $("#ident").val("لا يوجد")
        }
        if(account_c == "") {
            $("#account").val("لا يوجد")
        }
        if(textNote_c == "") {
            $("#anotherinfo").val("لا يوجد")
        }
    });



  $(document).ready( function(){
    if(  $( window ).width() <= 600 ){
    var x_heads = [] ;
    var thds = $("table").find("thead").children("tr").children("th") ;
    var tdds = $("table").find("tbody").children("tr");
    thds.each( function( index ){
        x_heads[index] = $(this).html();
    });
    tdds.each( function( index ){
      var TDSS = $(this).children("td") ;
      TDSS.each( function( indexZ ){
        var OLD_TEXT = $(this).html();
        if( x_heads[indexZ] == "التفاصيل" ){
          var asds = "detsxx";
        }else if( x_heads[indexZ] == "التحويل" ){
          var asds = "detsxsssawx";
        }else{
          var asds = " ";
        }
        $(this).html( '<span class="'+asds+'">' + x_heads[indexZ] + '</span><span class="'+asds+'">' + OLD_TEXT + '</span>' ) ;
      });
    });
    }
  });







});









