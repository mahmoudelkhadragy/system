<?php
class Main extends CI_Model {
  public function __construct()
  {
  // Call the CI_Model constructor
  parent::__construct();
  }

  function add_save_balance( $money , $money_f ){
    $aradas = array(
      "money" => $money ,
      "money_f" => $money_f ,
      "d" => date("j"),
      "m" => date("n"),
      "y" => date("Y"),
      "date" => time()
    );
    $this->db->insert("save_log" , $aradas ) ;
  }


}
