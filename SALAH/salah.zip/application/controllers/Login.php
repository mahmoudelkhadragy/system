<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
  public function index() {
    if( $_SERVER["REQUEST_METHOD"] == "POST" ) {
        $this->db->where("id", "1");
        $setting = $this->db->get("settings")->result()[0];
        $user       = $_POST["name"] ;
        $pass       = $_POST["password"] ;
        $formErrors = array();

        if( strlen($user) <= 4 ) {
            $xxxx['formErrors'][] = "عذرا الاسم لابد ان يزيد عن <strong>4</strong> أحرف";
        }
        if( strlen($pass) < 4 ) {
            $xxxx['formErrors'][] = "عذرا الباسورد لابد ان يزيد عن <strong>3</strong> أحرف";
        }

        if ( $user == "zakaria" && $pass == $setting->password ) {
            $_SESSION['logined'] = "true";
            redirect("home");
        }else{
            echo "U: " .$user . " P: ". $pass ;
        }
    }
        $xxxx['cssclass'] = "login" ;
        $xxxx['showheader'] = "false" ;
        $xxxx['showfooter'] = "false" ;
        $this->load->view('salahzakaria/header' , $xxxx );
    $this->load->view('salahzakaria/login' , $xxxx );
    $this->load->view('salahzakaria/footer' , $xxxx );
  }
}
