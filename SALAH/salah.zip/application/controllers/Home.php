<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
  public function index()
  {
        if ( $_SESSION['logined'] == "true" ){
        $xxxx['cssclass'] = "home" ;
        $xxxx['showheader'] = "true" ;
        $xxxx['showfooter'] = "true" ;
            if (isset($_POST["buyprice"])) {

                $settings = array(
                    "buyprice" => $_POST["buyprice"],
                    "sellprice" => $_POST["sellprice"]
                );
                if ( !empty($_POST["update_password"]) ) {
                    $settings["password"] = $_POST["update_password"];
                }
                $this->db->where("id", "1");
                $this->db->update("settings", $settings);
                $xxxx['showoko'] = "true" ;
            }
    $this->load->view('salahzakaria/header', $xxxx);
    $this->load->view('salahzakaria/content', $xxxx);
    $this->load->view('salahzakaria/footer', $xxxx);
        }else{
            redirect("login");
        }
  }
  public function add_client()
  {
        if ( $_SESSION['logined'] == "true" ){
        $xxxx['cssclass'] = "add_client" ;
        $xxxx['showheader'] = "true" ;
        $xxxx['showfooter'] = "true" ;
            if (isset($_POST["client"])) {

                $suppliers = array(
                    "client" => $_POST["client"],
                    "client_address" => $_POST["client_address"],
                    "client_phone" => $_POST["client_phone"],
                    "date" => time(),
                    "client_ident" => $_POST["client_ident"],
                    "client_account" => $_POST["client_account"],
                    "client_info" => $_POST["client_info"]
                );

                $this->db->insert("suppliers", $suppliers);
                $xxxx['showoko'] = "true" ;
            }

    $this->load->view('salahzakaria/header', $xxxx);
    $this->load->view('salahzakaria/add_client', $xxxx);
    $this->load->view('salahzakaria/footer', $xxxx);
        }else{
            redirect("login");
        }
  }
    public function clients() {
        if ( $_SESSION['logined'] == "true" ){
        $xxxx['cssclass'] = "clients" ;
        $xxxx['showheader'] = "true" ;
        $xxxx['showfooter'] = "true" ;
             if (isset($_POST["client"])) {

                $clients = array(
                    "client" => $_POST["client"],
                    "client_address" => $_POST["client_address"],
                    "client_phone" => $_POST["client_phone"],
                    "date" => time(),
                    "client_ident" => $_POST["client_ident"],
                    "client_account" => $_POST["client_account"],
                    "client_info" => $_POST["client_info"]
                );

                $this->db->insert("clients", $clients);
                $xxxx['showoko'] = "true" ;
            }
    $this->load->view('salahzakaria/header', $xxxx);
    $this->load->view('salahzakaria/clients', $xxxx);
    $this->load->view('salahzakaria/footer', $xxxx);
        } else {
            redirect("login");
        }
  }
    public function suppliers(){
        if ( $_SESSION['logined'] == "true" ){
        $xxxx['cssclass'] = "suppliers" ;
        $xxxx['showheader'] = "true" ;
        $xxxx['showfooter'] = "true" ;

    $this->load->view('salahzakaria/header', $xxxx);
    $this->load->view('salahzakaria/suppliers', $xxxx);
    $this->load->view('salahzakaria/footer', $xxxx);
        }else{
            redirect("login");
        }
  }
    public function clients_content()
  {
        if ( $_SESSION['logined'] == "true" ){
        $xxxx['cssclass'] = "clients_content" ;
        $xxxx['showheader'] = "true" ;
        $xxxx['showfooter'] = "true" ;

    $this->load->view('salahzakaria/header', $xxxx);
    $this->load->view('salahzakaria/clients_content', $xxxx);
    $this->load->view('salahzakaria/footer', $xxxx);
        }else{
            redirect("login");
        }
  }
    public function clients_info( $id_id )
  {
        if ( $_SESSION['logined'] == "true" ){
        $xxxx['cssclass'] = "clients_info" ;
        $xxxx['showheader'] = "true" ;
        $xxxx['showfooter'] = "true" ;
            if (isset($_POST["egprice"])) {
                $this->db->where("id", "1");
                $setting = $this->db->get("settings")->result()[0];
                $new_total = ( $setting->balance - $_POST['egprice'] );
                $new_ballance_f = ( $setting->balance_f - $_POST['dolprice'] );
                $new_earning = ( $setting->earning + $_POST['money'] );
                $infos = array(
                    "clientsid" => $id_id,
                    "suplierid" => $_POST['suplier'],
                    "type" => $_POST["type"],
                    "egprice" => $_POST["egprice"],
                    "dolprice" => $_POST["dolprice"],
                    "buyprice" => $_POST["buyprice"],
                    "sellprice" => $_POST["sellprice"],
                    "money" => $_POST["money"],
                    "notes" => $_POST["notes"],
                    "d" => date("j"),
                    "m" => date("n"),
                    "y" => date("Y"),
                    "date" => time()
                );
                $this->db->insert("transition", $infos);
                $settings = array(
                    "balance" => $new_total,
                    "balance_f" => $new_ballance_f,
                    "earning" => $new_earning
                );
                $this->db->where("id", "1");
                $this->db->update("settings", $settings);
              $get_s_info = $this->db->get_where("suppliers" , array( "id" => $_POST['suplier'] ))->result()[0] ;
              $new_ballance = ( $get_s_info->balance - $_POST['egprice'] );
              $new_ballance_f = ( $get_s_info->balance_f - $_POST['dolprice'] ) ;
              $this->db->where( "id" , $_POST['suplier'] );
              $dx = array( "balance" => $new_ballance, "balance_f" => $new_ballance_f );
              $this->db->update( "suppliers" , $dx ) ;
              $this->main->add_save_balance( $new_ballance , $new_ballance_f );
              $xxxx['showoko'] = "true" ;


            }
        $xxxx['id_id'] = $id_id ;
    $this->load->view('salahzakaria/header', $xxxx);
    $this->load->view('salahzakaria/clients_info', $xxxx);
    $this->load->view('salahzakaria/footer', $xxxx);
        }else{
            redirect("login");
        }
  }

    public function suppliers_infos( $id_id )
  {
        if ( $_SESSION['logined'] == "true" ){
        $xxxx['cssclass'] = "suppliers_infos" ;
        $xxxx['showheader'] = "true" ;
        $xxxx['showfooter'] = "true" ;
            if (isset($_POST["add-incom-x"])) {
              $get_s_info = $this->db->get_where("suppliers" , array( "id" => $id_id ))->result()[0] ;
              /*/////////////////*/
              $supplierinfos = array(
                  "supplierid" => $id_id,
                  "getmoney" => $_POST["getmoney"],
                  "lebymoney" => $_POST["lebymoney"],
                  "price" => $_POST["price"],
                  "notes" => $_POST["notes"],
                  "d" => date("j"),
                  "m" => date("n"),
                  "y" => date("Y"),
                  "date" => time()
              );
              $this->db->insert("transfers", $supplierinfos);
              /*////////////////*/
              $new_ballance = ( $get_s_info->balance + $_POST['getmoney'] );
              $new_ballance_f = ( $get_s_info->balance_f + $_POST['lebymoney'] ) ;
              $this->db->where( "id" , $id_id );
              $dx = array( "balance" => $new_ballance, "balance_f" => $new_ballance_f );
              $this->db->update( "suppliers" , $dx ) ;

              $this->db->where("id", "1");
              $setting = $this->db->get("settings")->result()[0];
              $new_total = ( $setting->balance + $_POST['getmoney'] );
              $settings = array(
                  "balance" => $new_total,
                  "balance_f" => $new_ballance_f,
              );
              $this->db->where("id", "1");
              $this->db->update("settings", $settings);
              $this->main->add_save_balance( $new_ballance , $new_ballance_f );
              $xxxx['showoko'] = "true" ;
            }
        $xxxx['id_id'] = $id_id ;
          $this->load->view('salahzakaria/header', $xxxx);
          $this->load->view('salahzakaria/suppliers_infos', $xxxx);
          $this->load->view('salahzakaria/footer', $xxxx);
        }else{
            redirect("login");
        }
  }
  public function reports()
  {
    if ( $_SESSION['logined'] == "true" ){
    $xxxx['cssclass'] = "add_client" ;
    $xxxx['showheader'] = "true" ;
    $xxxx['showfooter'] = "true" ;
    $this->load->view('salahzakaria/header', $xxxx);
    $this->load->view('salahzakaria/reports', $xxxx);
    $this->load->view('salahzakaria/footer', $xxxx);
    }else{
    redirect("login");
    }
  }

}
