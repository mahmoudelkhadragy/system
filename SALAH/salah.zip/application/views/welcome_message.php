<link rel="stylesheet" href="<?php echo base_url("bootstrap.min.css"); ?>">
<link rel="stylesheet" href="<?php echo base_url("main.css"); ?>">
<?php
if ( $_SERVER['REQUEST_METHOD'] == "POST" ) {
    
        $user       = filter_var($_POST["name"], FILTER_SANITIZE_STRING);
        $pass       = $_POST["password"];
        $formErrors = array();

        if ( strlen($user) < 3 ) {
            $formErrors[] = 'user name must be more than <strong>3</strong> characters';
        }
        if ( strlen($pass) < 6 ) {
            $formErrors[] = 'password must be more than <strong>6</strong> characters';
        }
    }
    if( isset($_POST["name"]) ){
        if( $_POST["name"] == "mahmoud" && $_POST["password"] == "0000" ) {
            echo "بياناتك صحيحه يا زميلى <br>";
        } else {
            echo "بياناتك غلط يا زميلى <br>";
        }
    }
?>
<div class="container">
    <?php if(!empty($formErrors)) { ?>
    <div class="errors">
        <?php 
            foreach ($formErrors as $error) {
                echo $error . "<br>";
            }
        ?>
    </div>
<?php } ?>
    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data" >
        <label>Name</label>
        <input class="user"
               type="text" 
               name="name" 
               placeholder="type your name" 
               value="<?php if(isset($user)){echo $user;} ?>">
        <div class="alert alert-danger custom-alert user-alert">
            user name must be more than <strong>3</strong> characters
        </div>
        <label>password</label>
        <input class="passw"
               type="password" 
               name="password" 
               placeholder="type your password">
        <div class="alert alert-danger custom-alert user-pass">
            password must be more than <strong>6</strong> characters
        </div>
        <button type="submit">Send</button>
    </form>
</div>
<script src="<?php echo base_url("jquery-1.12.4.min.js"); ?>"></script>
<script src="<?php echo base_url("plugn.js"); ?>"></script>














