    <?php if ( $showfooter == "true" ){ ?>
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-5 col-xs-4">
                    الحاج صلاح ذكريا 
                </div>
                <div class="col-sm-7 col-xs-8 left-fo">
                    تم بواسطه محمد شكرى
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
    <script src="<?php echo base_url("salah_files/js/jquery-1.12.4.min.js"); ?>"></script>
    <script src="<?php echo base_url("salah_files/js/popper.min.js"); ?>"></script>
    <script src="<?php echo base_url("salah_files/js/bootstrap.min.js"); ?>"></script>
    <script src="<?php echo base_url("salah_files/js/jquery.quicksearch.min.js"); ?>"></script>
    <script src="<?php echo base_url("salah_files/js/plugn.js"); ?>"></script>
    </body>
</html>