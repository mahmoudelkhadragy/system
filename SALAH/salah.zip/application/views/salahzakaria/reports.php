<?php
    $this->db->order_by("id", "desc");
    $suppliers = $this->db->get("suppliers");
    $suppliers = $suppliers->result();
?>

<div class="patient-table">
    <div class="container">
        <h2 class="headh2 my-5"> البحث والتقارير </h2>
        <form action="" method="post" >
            <div class="row">
              <div class="col-md-4 new-section">
                <label> يوم </label>
                <select class="form-control" name="d">
                <option value="0" >الكل</option>
                <?php
                for( $i = 1 ; $i <= 31 ; $i++ ){
                ?>
                <option value="<?php echo $i ; ?>"><?php echo $i ; ?></option>
                <?php
                }
                ?>
                </select>
              </div>
              <div class="col-md-4 new-section">
                <label> شهر </label>
                <select class="form-control" name="m">
                <option value="0" >الكل</option>
                <?php
                for( $i = 1 ; $i <= 12 ; $i++ ){
                ?>
                <option value="<?php echo $i ; ?>"><?php echo $i ; ?></option>
                <?php
                }
                ?>
                </select>
              </div>
              <div class="col-md-4 new-section">
                <label> سنة </label>
                <select class="form-control" name="y">
                <option value="0" >الكل</option>
                <?php
                for( $i = 1990 ; $i <= 2030 ; $i++ ){
                ?>
                <option value="<?php echo $i ; ?>"><?php echo $i ; ?></option>
                <?php
                }
                ?>
                </select>
              </div>
          </div>
          <hr />
          <div class="row">
            <div class="col-6 col-md-3">
            <label >
              <input type="radio" name="type" checked value="earn" />
              <span>المكسب</span>
            </label>
            </div>
            <div class="col-6 col-md-3">
            <label >
              <input type="radio" name="type" value="pay" />
              <span>مددفوعات</span>
            </label>
            </div>
            <div class="col-6 col-md-3">
            <label >
              <input type="radio" name="type" value="income" />
              <span>واردات</span>
            </label>
            </div>
            <div class="col-6 col-md-3">
            <label >
              <input type="radio" name="type" value="save" />
              <span>الخزينة</span>
            </label>
            </div>
            <hr />
            <div class="col-6 col-md-6">
            <label >
              <input type="radio" name="type" value="moneym" />
              <span>مبالغ عند موردين</span>
            </label>
            </div>
            <div class="col-6 col-md-6">
            <label >
              <input type="radio" name="type" value="moneyx" />
              <span>مبالغ للموردين عندي</span>
            </label>
            </div>
          </div>
          <hr />
          <div class="text-left">
              <button type="submit" name="search" class="btn btn-dark btn-client"> بحث </button>
          </div>
        </form>
    <?php
    $this->db->order_by("id" ,"DESC");
    if( isset( $_POST['search'] ) ){
      if( $_POST['type'] != "moneym" AND $_POST['type'] != "moneyx" ){
        if( $_POST['d'] != "0" ){
          $this->db->where( "d" , $_POST['d'] ) ;
        }
        if( $_POST['m'] != "0" ){
          $this->db->where( "m" , $_POST['m'] ) ;
        }
        if( $_POST['y'] != "0" ){
          $this->db->where( "y" , $_POST['y'] ) ;
        }
      }
      if( $_POST['type'] == "earn" ){
        $qu = $this->db->get("transition")->result();
        $all_data = 0 ;
        foreach( $qu as $sq ){
          $all_data = ( $all_data + $sq->money ) ;
        }
      }
      if( $_POST['type'] == "pay" ){
        $qu = $this->db->get("transition")->result();
        $all_data = 0 ;
        foreach( $qu as $sq ){
          $all_data = ( $all_data + $sq->egprice ) ;
        }
      }
      if( $_POST['type'] == "income" ){
        $qu = $this->db->get("transfers")->result();
        $all_data = 0 ;
        foreach( $qu as $sq ){
          $all_data = ( $all_data + $sq->getmoney ) ;
        }
      }
      if( $_POST['type'] == "moneym" ){
        $this->db->where( "balance <" , 0 );
        $qu = $this->db->get("suppliers")->result();
        $all_data = 0 ;
        foreach( $qu as $sq ){
          $all_data = ( $all_data + $sq->balance ) ;
        }
      }
      if( $_POST['type'] == "moneyx" ){
        $this->db->where( "balance >" , 0 );
        $qu = $this->db->get("suppliers")->result();
        $all_data = 0 ;
        foreach( $qu as $sq ){
          $all_data = ( $all_data + $sq->balance ) ;
        }
      }
      if( $_POST['type'] == "save" ){
        $qu = $this->db->get("save_log")->result();
        $all_data = 0 ;
      }
    }
    if( isset( $_POST['search'] ) ){
    ?>
    <?php if(  $_POST['type'] != "save" ){ ?>
    <h2> الاجمالي : <?php echo $all_data ; ?> </h2>
    <?php } ?>
    <hr />
  <table class="table table-striped">
    <thead>
      <tr>
      <?php if( $_POST['type'] == "earn" || $_POST['type'] == "pay" ){ ?>
        <th scope="col">العميل</th>
        <th scope="col">التاريخ</th>
        <th scope="col">المبلغ بالمصرى</th>
        <th scope="col">المبلغ الاجنبي</th>
        <th scope="col">سعر الشراء</th>
        <th scope="col">سعر البيع</th>
        <th scope="col">نوع التحويل</th>
        <th scope="col">المكسب</th>
        <th scope="col">المورد</th>
        <th scope="col">ملاحظات</th>
      <?php } ?>
      <?php if( $_POST['type'] == "income" ){ ?>
        <th scope="col">المورد</th>
        <th scope="col">التاريخ</th>
        <th scope="col">المبلغ الموجود</th>
        <th scope="col">المبلغ بالليبى</th>
        <th scope="col">سعر العملة</th>
        <th scope="col">ملاحظات</th>
      <?php } ?>
      <?php if( $_POST['type'] == "moneym" || $_POST['type'] ==  "moneyx" ){ ?>
        <th scope="col">المورد</th>
        <th scope="col">المبلغ</th>
      <?php } ?>
      <?php if( $_POST['type'] == "save" ){ ?>
        <th scope="col">التاريخ</th>
        <th scope="col">المبلغ مصري</th>
        <th scope="col">المبلغ بالليبى</th>
      <?php } ?>
      </tr>
    </thead>
      <tbody>

        <?php if( $_POST['type'] == "earn" || $_POST['type'] == "pay" ){
            foreach( $qu as $value) { ?>
            <tr>
              <td><?php
              $sub__
          = $this->db->get_where("clients" , array( "id" => $value->clientsid ))->result()[0] ;
              ?>
              <a href="<?php echo base_url("home/suppliers_infos/" . $sub__->id) ?>" class="btn btn-dark info-patient"> <?php echo $sub__->client ; ?>  </a>
              </td>
              <td dir="ltr" style="text-align:center;"><?php echo date( "j/n/Y h:i A" , $value->date ) ;  ?></td>
              <td><?php echo $value->egprice ?></td>
              <td><?php echo $value->dolprice ?></td>
              <td><?php echo $value->buyprice ?></td>
              <td><?php echo $value->sellprice ?></td>
              <td><?php echo $value->type ?></td>
              <td><?php echo $value->money ?></td>
              <td><?php
              $sub__
          = $this->db->get_where("suppliers" , array( "id" => $value->suplierid ))->result()[0] ;
              ?>
              <a href="<?php echo base_url("home/suppliers_infos/" . $sub__->id) ?>" class="btn btn-dark info-patient"> <?php echo $sub__->client ; ?>  </a>
              </td>
              <td><?php echo $value->notes ?></td>
            </tr>
          <?php } } ?>

        <?php if( $_POST['type'] == "income" ){
            foreach( $qu as $value) { ?>
            <tr>
              <td><?php
              $sub__
          = $this->db->get_where("suppliers" , array( "id" => $value->supplierid ))->result()[0] ;
              ?>
              <a href="<?php echo base_url("home/suppliers_infos/" . $sub__->id) ?>" class="btn btn-dark info-patient"> <?php echo $sub__->client ; ?>  </a>
              </td>
              <td dir="ltr" style="text-align:center;"><?php echo date( "j/n/Y h:i A" , $value->date ) ;  ?></td>
              <td><?php echo $value->getmoney ?></td>
              <td><?php echo $value->lebymoney ?></td>
              <td><?php echo $value->price ?></td>
              <td><?php echo $value->notes ?></td>
            </tr>
          <?php } } ?>

        <?php if( $_POST['type'] == "moneym" || $_POST['type'] ==  "moneyx"  ){
            foreach( $qu as $value) { ?>
            <tr>
              <td><?php
              $sub__
          = $this->db->get_where("suppliers" , array( "id" => $value->id ))->result()[0] ;
              ?>
              <a href="<?php echo base_url("home/suppliers_infos/" . $sub__->id) ?>" class="btn btn-dark info-patient"> <?php echo $sub__->client ; ?>  </a>
              </td>
              <td><?php echo $value->balance ?></td>
            </tr>
          <?php } } ?>

        <?php if( $_POST['type'] == "save" ){
            foreach( $qu as $value) { ?>
            <tr>
              <td dir="ltr" style="text-align:center;"><?php echo date( "j/n/Y h:i A" , $value->date ) ;  ?></td>
              <td><?php echo $value->money ; ?></td>
              <td><?php echo $value->money_f ; ?></td>
            </tr>
          <?php } } ?>

      </tbody>
    </table>
      <?php } ?>
    </div>
</div>
