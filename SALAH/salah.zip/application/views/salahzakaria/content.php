<?php
    $this->db->where("id", "1");
    $setting = $this->db->get("settings");
    $setting = $setting->result()[0];
?>
<div class="patient-table">
    <div class="container">
        <h2 class="headh2 my-5">تقرير الدخل العام</h2>
        <form method="post">
            <div class="row">
                <div class="col-md-6 ">
                    <p class="head-balance my-4">الرصيد الحالى</p>
                    <div class="show-balance"><?php echo $setting->balance ?></div>
                </div>
                <div class="col-md-6">
                    <p class="head-balance my-4">اضف سعر العمله</p>
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label>سعر التعامل</label>
                            <input required step=".01" value="<?php echo $setting->buyprice ?>" type="number" class="form-control" name="buyprice" placeholder="ادخل سعر الشراء">
                        </div>
                        <div class="col-md-6 form-group">
                            <label>سعر الليبى الاصلى</label>
                            <input required step=".01" value="<?php echo $setting->sellprice ?>" type="number" class="form-control" name="sellprice" placeholder="ادخل سعر البيع">
                        </div>
                    </div>
                </div>
                </div>
                <div class="row">
                    <div class="col-md-6 ">
                        <p class="head-balance my-1">اجمالى المكسب</p>
                        <div class="show-balance"><?php echo $setting->earning ?></div>
                    </div>
                    <div class="col-md-6">
                        <label for="update-pass">تحديث الباسوورد</label>
                        <input type="text" class="form-control" name="update_password" id="update-pass" placeholder="ادخل الباسورد الجديد">
                    </div>
                </div>    
            <button type="submit" class="btn btn-dark btn-patient fbtn">تحديث السعر</button>
            <div class="clear"></div>
        </form>    
    </div>    
</div>