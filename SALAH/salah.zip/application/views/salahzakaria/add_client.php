
<div class="fill_info">
    <div class="container">
        <h2 class="headh2 my-5">اضافة المورد</h2>
        <form class="clients-form supplier-form" method="post">
        <?php if( isset($showoko) ){ ?>
            <div class="alertme2">تمت الإضافة بنجاح</div>
            <script>
                setTimeout(function() {
                    $(".alertme2").slideUp(200);
                }, 1500);
            </script>
        <?php } ?>
        <div class="form-group">
            <label for="supplier">الأسم</label>
            <input required type="text" class="form-control" name="client" id="supplier" placeholder="ادخل اسم المورد">
        </div>
        <div class="form-group">
            <label for="sup_address">العنوان</label>
            <input type="text" class="form-control" name="client_address" id="sup_address" placeholder="ادخل عنوان المورد">
        </div>
        <div class="row">
            <div class="col-md-6 form-group">
                <label for="sup_phone">رقم الهاتف</label>
                <input type="tel" class="form-control" name="client_phone" id="sup_phone" placeholder="ادخل رقم الهاتف">
            </div>
            <div class="col-md-6 form-group">
                <label for="sup_ident">رقم البطاقة</label>
                <input type="tel" class="form-control" name="client_ident" id="sup_ident" placeholder="ادخل رقم بطاقه المورد">
            </div>
        </div>    
        <div class="form-group">
            <label for="sup_account">الحساب البنكى</label>
            <input type="tel" class="form-control" name="client_account" id="sup_account" placeholder="ادخل الحساب البنكى للمورد">
        </div>
        <div class="form-group">
            <label for="sup_anotherinfo">معلومات اخرى</label>
            <textarea class="form-control" name="client_info" id="sup_anotherinfo" placeholder="اضف اى معلومات اخرى"></textarea>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <button type="submit" class="btn btn-dark btn-client">اضف البيانات</button>
            </div>
            <div class="col-sm-6">
                <a href="<?php echo base_url("home/suppliers") ?>" class="btn btn-dark goto-client">الذهاب الى كشف الموردين</a>
            </div>    
        </div>
    </form>
    </div>    
</div>









