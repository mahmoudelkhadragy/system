
<div class="contact-form">
    <h2 class="head-login">تسجيل الدخول</h2>
    <div class="icon-admin">
        <i class="fas fa-users fa-fw fa-4x"></i>
    </div>
    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data" >
        <label class="label-log">الأسم</label>
        <input class="user form-control"
               type="text" 
               name="name" 
               placeholder="اكتب اسمك" 
               value="<?php if(isset($user)){echo $user;} ?>">

        <div class="alert alert-danger custom-alert user-alert">
            عذرا الاسم لابد ان يزيد عن <strong>4</strong> أحرف
        </div>

        <label class="label-log">الباسورد</label>
        <input class="passw form-control"
               type="password" 
               name="password" 
               placeholder="اكتب الباسورد">

        <div class="alert alert-danger custom-alert pass-alert">
            عذرا الباسورد لابد ان يزيد عن <strong>6</strong> أحرف
        </div>

        <button class="btn-block btn_login" type="submit">دخول</button>
    </form>
</div>











