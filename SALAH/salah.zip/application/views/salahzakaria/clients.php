<div class="container">
    <h2 class="headh2 my-4">اضافة العملاء</h2>
    <form class="clients-form" method="post">
        <?php if( isset($showoko) ){ ?>
            <div class="alertme2">تمت الإضافة بنجاح</div>
            <script>
                setTimeout(function() {
                    $(".alertme2").slideUp(200);
                }, 1500);
            </script>
        <?php } ?>
        <div class="form-group">
            <label for="name">الأسم</label>
            <input required type="text" class="form-control" name="client" id="name" placeholder="ادخل اسم العميل">
        </div>
        <div class="form-group">
            <label for="address">العنوان</label>
            <input type="text" class="form-control" name="client_address" id="address" placeholder="ادخل عنوان العميل">
        </div>
        <div class="row">
            <div class="col-md-6 form-group">
                <label for="phone">رقم الهاتف</label>
                <input type="tel" class="form-control" name="client_phone" id="phone" placeholder="ادخل رقم الهاتف">
            </div>
            <div class="col-md-6 form-group">
                <label for="ident">رقم البطاقة</label>
                <input type="tel" class="form-control" name="client_ident" id="ident" placeholder="ادخل رقم بطاقه العميل">
            </div>
        </div>
        <div class="form-group">
            <label for="account">الحساب البنكى</label>
            <input type="tel" class="form-control" name="client_account" id="account" placeholder="ادخل الحساب البنكى للعميل">
        </div>
        <div class="form-group">
            <label for="anotherinfo">معلومات اخرى</label>
            <textarea class="form-control" name="client_info" id="anotherinfo" placeholder="اضف اى معلومات اخرى"></textarea>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <button type="submit" class="btn btn-dark btn-client">اضف البيانات</button>
            </div>
            <div class="col-sm-6">
                <a href="<?php echo base_url("home/clients_content") ?>" class="btn btn-dark goto-client mb-3">الذهاب الى كشف العملاء</a>
            </div>
        </div>
    </form>
</div>




