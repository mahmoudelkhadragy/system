
<?php
    $this->db->where("id", $id_id);
    $clients = $this->db->get("clients");
    $clients = $clients->result()[0];
?>
<?php
    $this->db->where("clientsid", $id_id);
    $this->db->order_by("id", "desc");
    $transitions = $this->db->get("transition");
    $transitions = $transitions->result();
?>
<?php
    $this->db->where("id", "1");
    $setting = $this->db->get("settings");
    $setting = $setting->result()[0];

    $this->db->order_by("id", "desc");
    $suppliers = $this->db->get("suppliers");
    $suppliers = $suppliers->result();

?>
<?php if( isset($showoko) ){ ?>
<div class="alertme2">تمت الإضافة بنجاح</div>
<script>
setTimeout(function() {
$(".alertme2").slideUp(200);
}, 1500);
</script>
<?php } ?>

<div class="patient-profile">
    <div class="container">
        <h2 class="headh2 my-5">معلومات العميل</h2>
        <div class="row">

            <div class="col-md-6 mt-5">
                <div class="row">
                    <div class="col-md-4">
                        <div class="single-id">الإسم</div>
                    </div>
                    <div class="col-md-8">
                        <div class="single-content"><?php echo $clients->client ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="single-id">العنوان</div>
                    </div>
                    <div class="col-md-8">
                        <div class="single-content"><?php echo $clients->client_address ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="single-id">رقم الهاتف</div>
                    </div>
                    <div class="col-md-8">
                        <div class="single-content"><?php echo $clients->client_phone ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="single-id">رقم البطاقة</div>
                    </div>
                    <div class="col-md-8">
                        <div class="single-content"><?php echo $clients->client_ident ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="single-id">رقم الحساب</div>
                    </div>
                    <div class="col-md-8">
                        <div class="single-content"><?php echo $clients->client_account ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="single-id">معلومات اضافيه</div>
                    </div>
                    <div class="col-md-8">
                        <div class="single-content"><?php echo $clients->client_info ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <h3 class="headh2 mb-4">اضافة تحويل</h3>
                <form method="post" class="profile_form_patient">
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="eg-price">المبلغ بالمصرى</label>
                            <input step=".01" required type="number" class="form-control" name="egprice" id="eg-price" placeholder="ادخل المبلغ بالمصرى">
                        </div>
                        <div class="col-md-6 form-group">
                            <label for="dollar-price">المبلغ بالليبى</label>
                            <input step=".01" type="number" class="form-control" name="dolprice" id="dollar-price" placeholder="المبلغ الاجنبي">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 form-group">
                            <label for="eg-price">المورد</label>
                            <select name="suplier" class="form-control">
                            <?php foreach( $suppliers as $sub){  ?>
                                <option value="<?php echo $sub->id  ; ?>"><?php echo $sub->client  ; ?></option>
                             <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="buy-price">سعر التعامل</label>
                            <input step=".01" value="<?php echo $setting->buyprice ?>" required type="number" class="form-control" name="buyprice" id="buy-price" placeholder="ادخل سعر الشراء">
                        </div>
                        <div class="col-md-6 form-group">
                            <label for="sell-price">سعر الليبى الاصلى</label>
                            <input step=".01" value="<?php echo $setting->sellprice ?>" required type="number" class="form-control" name="sellprice" id="sell-price" placeholder="ادخل سعر البيع">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>نوع التحويل</label>
                        <div class="row">
                            <div class="col-md-3">
                                <input checked type="radio" name="type" id="aa" value="بريد">
                                <label class="for-radio" for="aa">بريد</label>
                            </div>
                            <div class="col-md-3">
                                <input type="radio" name="type" id="bb" value="بنك اهلى">
                                <label class="for-radio" for="bb">بنك اهلى</label>
                            </div>
                            <div class="col-md-3">
                                <input type="radio" name="type" id="cc" value="بنك مصر">
                                <label class="for-radio" for="cc">بنك مصر</label>
                            </div>
                            <div class="col-md-3">
                                <input type="radio" name="type" id="ff" value="تسليم باليد">
                                <label class="for-radio" for="ff">تسليم باليد</label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="saving">المكسب</label>
                        <input readonly required type="text" class="form-control" name="money" id="saving" placeholder="قيمة المكسب">
                    </div>
                    <div class="form-group">
                        <label for="saving">ملاحظات</label>
                        <input type="text" class="form-control" name="notes" id="notes" placeholder="ملاحظات">
                    </div>
                    <button type="submit" class="btn btn-dark btn-patient">اضف التحويل</button>
                </form>
            </div>
        </div>
        <table class="table table-striped">
            <thead>
                <tr>
                  <th scope="col">التاريخ</th>
                  <th scope="col">المبلغ بالمصرى</th>
                  <th scope="col">المبلغ الاجنبي</th>
                  <th scope="col">سعر الشراء</th>
                  <th scope="col">سعر البيع</th>
                  <th scope="col">نوع التحويل</th>
                  <th scope="col">المكسب</th>
                  <th scope="col">المورد</th>
                  <th scope="col">ملاحظات</th>
                </tr>
            </thead>
          <tbody>

             <?php
                foreach($transitions as $value) { ?>
                    <tr>
                      <td dir="ltr" style="text-align:center;"><?php echo date( "j/n/Y h:i A" , $value->date ) ;  ?></td>
                      <td><?php echo $value->egprice ?></td>
                      <td><?php echo $value->dolprice ?></td>
                      <td><?php echo $value->buyprice ?></td>
                      <td><?php echo $value->sellprice ?></td>
                      <td><?php echo $value->type ?></td>
                      <td><?php echo $value->money ?></td>
                      <td><?php
                      $sub__
                  = $this->db->get_where("suppliers" , array( "id" => $value->suplierid ))->result()[0] ;
                      ?>
                      <a href="<?php echo base_url("home/suppliers_infos/" . $sub__->id) ?>" class="btn btn-dark info-patient"> <?php echo $sub__->client ; ?>  </a>
                      </td>
                      <td><?php echo $value->notes ?></td>
                    </tr>
            <?php } ?>

          </tbody>
        </table>
    </div>
</div>
