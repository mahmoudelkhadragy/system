<?php
    $this->db->order_by("id", "desc");
    $suppliers = $this->db->get("suppliers");
    $suppliers = $suppliers->result();
?>

<div class="patient-table">
    <div class="container">
        <h2 class="headh2 my-5">كشف الموردين</h2>
        <form>
            <div class="row">
                <div class="col-md-8 new-section">
                    <a href="<?php echo base_url("home/add_client") ?>" class="btn-dark mb-3">أضف مورد جديد</a>
                </div>
                <div class="col-md-4 serch-sec">
                    <input id="search" type="text" class="form-control mb-3" placeholder="اكتب ما تبحث عنه">
                    <span class="icon-search"><i class="fas fa-search"></i></span>
                </div>
            </div>
        </form>
            <table class="table table-striped">
              <thead>
                <tr>
                  <th scope="col">رقم</th>
                  <th scope="col">الأسم</th>
                  <th scope="col">العنوان</th>
                  <th scope="col">رقم الهاتف</th>
                  <th scope="col">رقم البطاقة</th>
                  <th scope="col">رقم الحساب</th>
                  <th scope="col">التفاصيل</th>
                  <th scope="col">التحويل</th>
                </tr>
              </thead>
              <tbody>

                <?php
                foreach($suppliers as $value) { ?>
                    <tr>
                      <td><?php echo $value->id ?></td>
                      <td><?php echo $value->client ?></td>
                      <td><?php echo $value->client_address ?></td>
                      <td><?php echo $value->client_phone ?></td>
                      <td><?php echo $value->client_ident ?></td>
                      <td><?php echo $value->client_account ?></td>
                      <td><?php echo $value->client_info ?></td>
                      <td><a href="<?php echo base_url("home/suppliers_infos/" . $value->id) ?>" class="btn btn-dark info-patient"> الصفحة الشخصية </a></td>
                    </tr>
                <?php } ?>

              </tbody>
            </table>
    </div>
</div>


