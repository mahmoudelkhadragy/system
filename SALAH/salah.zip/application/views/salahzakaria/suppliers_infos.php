<?php
    $this->db->where("id", $id_id);
    $suppliers = $this->db->get("suppliers");
    $suppliers = $suppliers->result()[0];

    $this->db->where("id", "1");
    $setting = $this->db->get("settings");
    $setting = $setting->result()[0];

    $this->db->where("supplierid", $id_id);
    $this->db->order_by("id", "desc");
    $supply = $this->db->get("transfers");
    $supply = $supply->result();
?>
<?php if( isset($showoko) ){ ?>
<div class="alertme2">تمت الإضافة بنجاح</div>
<script>
setTimeout(function() {
$(".alertme2").slideUp(200);
}, 1500);
</script>
<?php } ?>

<div class="patient-profile">
    <div class="container">
        <h2 class="headh2 my-5">معلومات المورد</h2>
        <div class="row">
            <div class="col-md-6 ">
                    <p class="head-balance my-3">الرصيد الكلى</p>
                    <div class="show-balance"><?php echo $suppliers->balance ?></div>
            </div>
            <div class="col-md-6 "></div>
            <div class="col-md-6 mt-5">
                <div class="row">
                    <div class="col-md-4">
                        <div class="single-id">الإسم</div>
                    </div>
                    <div class="col-md-8">
                        <div class="single-content"><?php echo $suppliers->client ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="single-id">العنوان</div>
                    </div>
                    <div class="col-md-8">
                        <div class="single-content"><?php echo $suppliers->client_address ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="single-id">رقم الهاتف</div>
                    </div>
                    <div class="col-md-8">
                        <div class="single-content"><?php echo $suppliers->client_phone ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="single-id">رقم البطاقة</div>
                    </div>
                    <div class="col-md-8">
                        <div class="single-content"><?php echo $suppliers->client_ident ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="single-id">رقم الحساب</div>
                    </div>
                    <div class="col-md-8">
                        <div class="single-content"><?php echo $suppliers->client_account ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="single-id">معلومات اضافيه</div>
                    </div>
                    <div class="col-md-8">
                        <div class="single-content"><?php echo $suppliers->client_info ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <h3 class="headh2 mb-5">اضافة تحويل</h3>
                <form method="post" class="profile_form_patient">
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label class="label_sup" for="exist"> مبلغ التحويل </label>
                            <input step=".01" required type="number" class="form-control" name="getmoney" id="exist" placeholder="ادخل المبلغ بالمصرى">
                        </div>
                        <div class="col-md-6 form-group">
                            <label class="label_sup" for="lebe">المبلغ بالعملة الاجنبية</label>
                            <input step=".01" required type="number" class="form-control" name="lebymoney" id="lebe" placeholder=" تولد تلقائيا ">
                        </div>
                        <div class="col-md-6 form-group">
                            <label class="label_sup" for="buyprice">سعر العملة</label>
                            <input step=".01" required type="number" class="form-control" name="price" value="<?php echo $setting->buyprice ?>" id="price" placeholder="ادخل سعر العملة">
                        </div>
                        <div class="col-md-12 form-group">
                            <label class="label_sup" for="note">ملاحظات
                            <textarea name="notes" id="notes" class="form-control"  placeholder="ملاحظات"></textarea>
                            </label>
                        </div>
                    </div>
                    <button type="submit" name="add-incom-x" class="btn btn-dark btn-patient">اضف التحويل</button>
                </form>
            </div>
        </div>
        <table class="table table-striped my-3">
            <thead>
                <tr>
                  <th scope="col">التاريخ</th>
                  <th scope="col">المبلغ الموجود</th>
                  <th scope="col">المبلغ بالليبى</th>
                  <th scope="col">سعر العملة</th>
                  <th scope="col">ملاحظات</th>
                </tr>
            </thead>
          <tbody>

             <?php
                foreach($supply as $value) { ?>
                    <tr>
                      <td dir="ltr" style="text-align:center;"><?php echo date( "j/n/Y h:i A" , $value->date ) ;  ?></td>
                      <td><?php echo $value->getmoney ?></td>
                      <td><?php echo $value->lebymoney ?></td>
                      <td><?php echo $value->price ?></td>
                      <td><?php echo $value->notes ?></td>
                    </tr>
            <?php } ?>

          </tbody>
        </table>
    </div>
</div>
