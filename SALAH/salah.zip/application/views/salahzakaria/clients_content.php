<?php
    $this->db->order_by("id", "desc");
    $clients = $this->db->get("clients");
    $clients = $clients->result();
?>
<?php if( isset($showoko) ){ ?>
<div class="alertme2">تمت الإضافة بنجاح</div>
<script>
setTimeout(function() {
$(".alertme2").slideUp(200);
}, 1500);
</script>
<?php } ?>
<div class="patient-table">
    <div class="container">
        <h2 class="headh2 my-5">كشف العملاء</h2>
        <form>
            <div class="row">
                <div class="col-md-8 new-section">
                    <a href="<?php echo base_url("home/clients") ?>" class="btn-dark mb-3">أضف عميل جديد</a>
                </div>
                <div class="col-md-4 serch-sec">
                    <input id="search" type="text" class="form-control mb-3" placeholder="اكتب ما تبحث عنه">
                    <span class="icon-search"><i class="fas fa-search"></i></span>
                </div>
            </div>
        </form>
        <table class="table table-striped">
          <thead>
            <tr>
              <th scope="col">رقم</th>
              <th scope="col">الأسم</th>
              <th scope="col">العنوان</th>
              <th scope="col">رقم الهاتف</th>
              <th scope="col">رقم البطاقة</th>
              <th scope="col">رقم الحساب</th>
              <th scope="col">التفاصيل</th>
              <th scope="col">تحويل</th>
            </tr>
          </thead>
          <tbody>

            <?php
            foreach($clients as $value) { ?>
                <tr>
                  <td><?php echo $value->id ?></td>
                  <td><?php echo $value->client ?></td>
                  <td><?php echo $value->client_address ?></td>
                  <td><?php echo $value->client_phone ?></td>
                  <td><?php echo $value->client_ident ?></td>
                  <td><?php echo $value->client_account ?></td>
                  <td><?php echo $value->client_info ?></td>
                  <td><a href="<?php echo base_url("home/clients_info/" . $value->id) ?>" class="btn btn-dark info-patient"> الصفحة الشخصية </a></td>
                </tr>
            <?php } ?>

          </tbody>
        </table>
    </div>
</div>
